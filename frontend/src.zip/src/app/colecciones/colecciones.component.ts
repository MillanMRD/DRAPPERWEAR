import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-colecciones',
  templateUrl: './colecciones.component.html',
  styleUrls: ['./colecciones.component.scss']
})
export class ColeccionesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
