import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-noticias',
  templateUrl: './noticias.component.html',
  styleUrls: ['./noticias.component.scss']
})
export class NoticiasComponent implements OnInit {
  producto = "/assets/images/drapper.png"

  constructor() { }

  ngOnInit(): void {
  }

}
