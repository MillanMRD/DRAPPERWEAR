export interface Producto {
    ID_Producto: number,
    Nombre: string,
    Descripcion: string,
    Precio: number,
    Stock: number
}
