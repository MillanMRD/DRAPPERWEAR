import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Producto } from './producto';
@Injectable({
  providedIn: 'root'
})
export class ProductoService {

  private apiURL = "http://localhost:8000/api";

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }
  constructor(private httpClient: HttpClient) { }

  getAll(): Observable<Producto[]> {
    return this.httpClient.get<Producto[]>(this.apiURL + '/producto/index')
      .pipe(
        catchError(this.errorHandler)
      )
  }

  create(producto: any): Observable<Producto> {
    return this.httpClient.post<Producto>(this.apiURL + '/producto/store', JSON.stringify(producto), this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  find(id: any): Observable<Producto> {
    return this.httpClient.get<Producto>(this.apiURL + '/producto/show/' + id)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  update(id: any, person: any): Observable<Producto> {
    return this.httpClient.post<Producto>(this.apiURL + '/producto/update/' + id, JSON.stringify(person), this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  delete(id: any) {
    return this.httpClient.delete<Producto>(this.apiURL + '/producto/destroy/' + id, this.httpOptions)
      .pipe(
        catchError(this.errorHandler)
      )
  }

  errorHandler(error: any) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = error.error.message;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}
